const canvas = document.getElementById('theCanvas');
const ctx = canvas.getContext('2d');
const clearButton = document.getElementById('clear');
const resizeButton = document.getElementById('resize');

const MIN_X = 200;
const MIN_Y = 200;
const MAX_X = 1500;
const MAX_Y = 700;

let canvasSizeX = canvas.width;
let canvasSizeY = canvas.height;

function applyStrokeColors() {
  ctx.lineWidth = 10;
  ctx.strokeStyle = '#f879ce';
}

function startDrawing(e) {
  isDrawing = true;
  draw(e);
}

function draw(e) {
  if (!isDrawing) return;
  ctx.lineTo(e.clientX - canvas.offsetLeft, e.clientY - canvas.offsetTop);
  ctx.stroke();
}
// Event when entering the canvas from the sides
canvas.addEventListener('mouseover', (e) => startDrawing(e));

// Event when moving on the canvas the canvas
canvas.addEventListener('mousemove', (e) => draw(e));

// Event when clicking on the canvas
canvas.addEventListener('click', (e) => isDrawing = false);

clearButton.addEventListener('click', () => {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.beginPath();
});

resizeButton.addEventListener('click', () => {
  const newSizeX = prompt(`Enter new canvas width X (between ${MIN_X} and ${MAX_X}):`);
  const sizeX = parseInt(newSizeX, 10);

  const newSizeY = prompt(`Enter new canvas height Y (between ${MIN_Y} and ${MAX_Y}):`);
  const sizeY = parseInt(newSizeY, 10);

  if ((sizeX >= MIN_X && sizeX <= MAX_X) && (MIN_Y >= 1 && sizeY <= MAX_Y)) {
    canvasSizeX = sizeX;
    canvasSizeY = sizeY;

    canvas.width = canvasSizeX
    canvas.height = canvasSizeY

    applyStrokeColors()
  } else {
    alert(`ERROR! Invalid sizes! Please enter a valid size between ${MIN_X} and ${MAX_X} for X and ${MIN_Y} and ${MAX_Y} for Y .`);
  }
});

applyStrokeColors()